window._config = {
    cognito: {
        userPoolId: 'ca-central-1_Cj6p9n0Wr',
        region: 'ca-central-1',
		clientId: '7sbkgkrd4d0i5iafnebjk4bmim' 
    },
};

